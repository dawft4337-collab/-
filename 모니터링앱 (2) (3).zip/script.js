const allWordsData = [
  // 🔥 1~36 완성본
  {word: "ねえ(ねえ)", audio: "audio/lyrics1.mp3", meaning: "이봐/야"},
  {word: "あたし(あたし)", audio: "audio/lyrics1.mp3", meaning: "나(여성어)"},
  {word: "知ってる(しってる)", audio: "audio/lyrics1.mp3", meaning: "알고 있어"},
  {word: "君(きみ)", audio: "audio/lyrics2.mp3", meaning: "너"},
  {word: "一人(ひとり)", audio: "audio/lyrics2.mp3", meaning: "혼자"},
  {word: "震える(ふるえる)", audio: "audio/lyrics3.mp3", meaning: "떨다"},
  {word: "声(こえ)", audio: "audio/lyrics3.mp3", meaning: "목소리"},
  {word: "漏れる(もれる)", audio: "audio/lyrics3.mp3", meaning: "새다"},
  {word: "正直(しょうじき)", audio: "audio/lyrics4.mp3", meaning: "솔직히"},
  {word: "バレる(ばれる)", audio: "audio/lyrics4.mp3", meaning: "들키다"},
  {word: "効く(きく)", audio: "audio/lyrics5.mp3", meaning: "효과가 있다"},
  {word: "普通(ふつう)", audio: "audio/lyrics6.mp3", meaning: "평범하다"},
  {word: "恥ずかしい(はずかしい)", audio: "audio/lyrics6.mp3", meaning: "부끄럽다"},
  {word: "隠す(かくす)", audio: "audio/lyrics6.mp3", meaning: "숨기다"},
  {word: "涙(なみだ)", audio: "audio/lyrics7.mp3", meaning: "눈물"},
  {word: "凹む(へこむ)", audio: "audio/lyrics8.mp3", meaning: "풀이 죽다"},
  {word: "弱音(よわね)", audio: "audio/lyrics8.mp3", meaning: "약한 소리"},
  {word: "朝(あさ)", audio: "audio/lyrics9.mp3", meaning: "아침"},
  {word: "一緒(いっしょ)", audio: "audio/lyrics9.mp3", meaning: "함께"},
  {word: "何度(なんど)", audio: "audio/lyrics10.mp3", meaning: "몇 번"},
  {word: "受け止める(うけとめる)", audio: "audio/lyrics10.mp3", meaning: "받아주다"},
  {word: "我慢(がまん)", audio: "audio/lyrics11.mp3", meaning: "참다"},
  {word: "出す(だす)", audio: "audio/lyrics11.mp3", meaning: "내다, 뿜다"},
  {word: "お願い(おねがい)", audio: "audio/lyrics12.mp3", meaning: "부탁"},
  {word: "欲しい(ほしい)", audio: "audio/lyrics12.mp3", meaning: "원하다"},
  {word: "慰める(なぐさめる)", audio: "audio/lyrics13.mp3", meaning: "위로하다"},
  {word: "愛(あい)", audio: "audio/lyrics13.mp3", meaning: "사랑"},
  {word: "才能(さいのう)", audio: "audio/lyrics13.mp3", meaning: "재능"},
  {word: "泣く(なく)", audio: "audio/lyrics14.mp3", meaning: "울다"},
  {word: "乾く(かわく)", audio: "audio/lyrics15.mp3", meaning: "마르다"},
  {word: "濡れる(ぬれる)", audio: "audio/lyrics15.mp3", meaning: "젖다"},
  {word: "いい(いい)", audio: "audio/lyrics16.mp3", meaning: "좋아"},
  {word: "舐める(なめる)", audio: "audio/lyrics17.mp3", meaning: "핥다"},
  {word: "飲み干す(のみほす)", audio: "audio/lyrics17.mp3", meaning: "다 마시다"},
  {word: "頼る(たよる)", audio: "audio/lyrics18.mp3", meaning: "의지하다"},
  {word: "シックラブ(しくらうぶ)", audio: "audio/lyrics18.mp3", meaning: "Sick Love"},
  {word: "最高(さいこう)", audio: "audio/lyrics18.mp3", meaning: "최고"},
  
  {word: "分ける(わける)", audio: "audio/lyrics19.mp3", meaning: "나누다"},
  
  {word: "痛い(いたい)", audio: "audio/lyrics20.mp3", meaning: "아프다"},
  {word: "感じる(かんじる)", audio: "audio/lyrics20.mp3", meaning: "느끼다"},
  
  {word: "吸い取る(すいとる)", audio: "audio/lyrics21.mp3", meaning: "빨아들이다"},
  {word: "救う(すくう)", audio: "audio/lyrics21.mp3", meaning: "구하다"},
  
  {word: "中(なか)", audio: "audio/lyrics22.mp3", meaning: "안, 속"},
  
  {word: "悔しがる(くやしがる)", audio: "audio/lyrics23.mp3", meaning: "분해하다"},
  
  {word: "知ってる(しってる)", audio: "audio/lyrics24.mp3", meaning: "알고 있어"},
  {word: "高まる(たかまる)", audio: "audio/lyrics24.mp3", meaning: "고조되다"},
  {word: "推す(おす)", audio: "audio/lyrics24.mp3", meaning: "응원하다"},
  
  {word: "できる(できる)", audio: "audio/lyrics25.mp3", meaning: "할 수 있다"},
  {word: "子(こ)", audio: "audio/lyrics25.mp3", meaning: "아이"},
  
  {word: "辛い(つらい)", audio: "audio/lyrics26.mp3", meaning: "괴롭다"},
  
  {word: "弱い(よわい)", audio: "audio/lyrics27.mp3", meaning: "약하다"},
  {word: "丁度いい(ちょうどいい)", audio: "audio/lyrics27.mp3", meaning: "딱 좋다"},
  
  {word: "名前(なまえ)", audio: "audio/lyrics28.mp3", meaning: "이름"},
  {word: "呼ぶ(よぶ)", audio: "audio/lyrics28.mp3", meaning: "부르다"},
  {word: "参上(さんじょう)", audio: "audio/lyrics28.mp3", meaning: "찾아옴"},
  
  {word: "歌う(うたう)", audio: "audio/lyrics29.mp3", meaning: "노래하다"},
  
  {word: "ソロプレイ", audio: "audio/lyrics30.mp3", meaning: "솔로 플레이"},
  {word: "お仕舞い(おしまい)", audio: "audio/lyrics30.mp3", meaning: "끝"},
  
  {word: "側(そば)", audio: "audio/lyrics31.mp3", meaning: "곁"},
  
  {word: "見守る(みまもる)", audio: "audio/lyrics32.mp3", meaning: "지켜보다"},
  
  {word: "怖くない(こわくない)", audio: "audio/lyrics34.mp3", meaning: "무섭지 않다"},
  
  {word: "忘れる(わすれる)", audio: "audio/lyrics35.mp3", meaning: "잊다"},
  
  {word: "我慢(がまん)", audio: "audio/lyrics36.mp3", meaning: "참다"},
  {word: "出す(だす)", audio: "audio/lyrics36.mp3", meaning: "내뱉다"}
  // ✅ 총 50개 완성! lyrics18.mp3부터 정확히 매칭
];

// =======================
// 🔥 DOM 요소
// =======================
const playSongBtn = document.getElementById("play-song");
const pauseSongBtn = document.getElementById("pause-song");
const mainSong = document.getElementById("main-song");
const currentLyrics = document.getElementById("current-lyrics");
const progressFill = document.getElementById("progress-fill");
const currentTimeEl = document.getElementById("current-time");
const totalTimeEl = document.getElementById("total-time");
const progressBar = document.getElementById("progress-bar");
const allWordsList = document.getElementById("all-words-list");

let currentShortAudio = null;

// =======================
// 🔥 오디오 로드
// =======================
mainSong.src = "audio/monitoring.mp3";
mainSong.load();

// =======================
// 🔥 유틸
// =======================
function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

// =======================
// 🔥 전체 단어 리스트 생성 (⭐ 핵심)
// =======================
function createAllWordsList() {
  allWordsList.innerHTML = "";

  allWordsData.forEach(wordData => {
    const btn = document.createElement("button");
    btn.className = "all-word-btn";
    btn.textContent = wordData.word;

    btn.addEventListener("click", () => {
      if (currentShortAudio) {
        currentShortAudio.pause();
        currentShortAudio.currentTime = 0;
      }

      mainSong.pause();
      playSongBtn.style.display = "inline-block";
      pauseSongBtn.style.display = "none";

      currentShortAudio = new Audio(wordData.audio);
      currentShortAudio.play().catch(() => {
        currentLyrics.textContent = "❌ 단어 음성 파일 확인!";
      });

      currentLyrics.innerHTML = `
        <div style="font-size:1.6em">${wordData.word}</div>
        <div style="color:#ffd700">${wordData.meaning}</div>
      `;
    });

    allWordsList.appendChild(btn);
  });
}

// =======================
// 🔥 원곡 재생
// =======================
playSongBtn.addEventListener("click", () => {
  if (currentShortAudio) {
    currentShortAudio.pause();
    currentShortAudio = null;
  }

  mainSong.currentTime = 0;
  mainSong.play();
  playSongBtn.style.display = "none";
  pauseSongBtn.style.display = "inline-block";
  currentLyrics.textContent = "🎵 원곡 재생 중...";
});

pauseSongBtn.addEventListener("click", () => {
  mainSong.pause();
  playSongBtn.style.display = "inline-block";
  pauseSongBtn.style.display = "none";
});

// =======================
// 🔥 진행바
// =======================
mainSong.addEventListener("timeupdate", () => {
  const p = (mainSong.currentTime / mainSong.duration) * 100 || 0;
  progressFill.style.width = p + "%";
  currentTimeEl.textContent = formatTime(mainSong.currentTime);
});

mainSong.addEventListener("loadedmetadata", () => {
  totalTimeEl.textContent = formatTime(mainSong.duration);
});

progressBar.addEventListener("click", e => {
  const rect = progressBar.getBoundingClientRect();
  const percent = (e.clientX - rect.left) / rect.width;
  mainSong.currentTime = percent * mainSong.duration;
});

// =======================
// 🔥 페이지 로드 시 실행 (⭐ 정답)
// =======================
document.addEventListener("DOMContentLoaded", () => {
  createAllWordsList();
});